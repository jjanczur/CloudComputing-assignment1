#!/usr/bin/env bash

./memsweep.sh