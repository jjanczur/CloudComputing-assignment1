#!/usr/bin/env bash

./linpack.sh