#!/usr/bin/env bash

source memsweep.sh