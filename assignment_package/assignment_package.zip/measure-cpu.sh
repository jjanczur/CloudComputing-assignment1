#!/usr/bin/env bash

source linpack.sh